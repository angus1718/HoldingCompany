package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

public class Interest extends AppCompatActivity {
    /*private RadioButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment1);

        btn1 = (RadioButton) findViewById(R.id.r_btn1);
        btn2 = (RadioButton) findViewById(R.id.r_btn2);
        btn3 = (RadioButton) findViewById(R.id.r_btn3);
        btn4 = (RadioButton) findViewById(R.id.r_btn4);
        btn5 = (RadioButton) findViewById(R.id.r_btn5);
        btn6 = (RadioButton) findViewById(R.id.r_btn6);
        btn7 = (RadioButton) findViewById(R.id.r_btn7);
        btn8 = (RadioButton) findViewById(R.id.r_btn8);
        btn9 = (RadioButton) findViewById(R.id.r_btn9);
        btn10 = (RadioButton) findViewById(R.id.r_btn10);
        btn11 = (RadioButton) findViewById(R.id.r_btn11);
        btn12 = (RadioButton) findViewById(R.id.r_btn12);
        btn13 = (RadioButton) findViewById(R.id.r_btn13);
        btn14 = (RadioButton) findViewById(R.id.r_btn14);
        btn15 = (RadioButton) findViewById(R.id.r_btn15);
        btn16 = (RadioButton) findViewById(R.id.r_btn16);
        btn17 = (RadioButton) findViewById(R.id.r_btn17);


        btn1.setOnClickListener(radioButtonClickListener);
        btn1.setOnClickListener(radioButtonClickListener);

    }
    RadioButton.OnClickListener radioButtonClickListener = new RadioButton.OnClickListener() {

        @Override
        public void onClick(View v) {

        }
    }
*/
}
