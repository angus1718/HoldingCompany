package com.example.app;

import java.util.List;

public class Listresult {


    public List<Result> getResultList() {
        return resultList;
    }

    public void setResultList(List<Result> resultList) {
        this.resultList = resultList;
    }

    private List<Result> resultList = null;
}
